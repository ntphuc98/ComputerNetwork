/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runable;

/**
 *
 * @author DELL
 */
public class LuongDuLieu {
	public static int snt;
	public static int i;

	public int getSnt() {
		return snt;
	}

	public void setSnt(int snt) {
		this.snt = snt;
	}

	public void setI(int i) {
		this.i = i;
	}

	public int getI() {
		return i;
	}

	public static int tong = 0;

	public int getTong() {
		return tong;
	}

	public void setTong(int tong) {
		this.tong = tong;

	}
}
