package runable;

public class data {
	public static int n = 0;

	data() {

	}

	public int getRandom() {
		return n;
	}

	public void setRandom(int n) {
		this.n = n;
	}
}
